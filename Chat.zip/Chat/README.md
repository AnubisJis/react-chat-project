### nextjs-admin-template

Admin dashboard template based on Next.js with [@paljs/ui](https://github.com/paljs/ui) component package

#### Setup:

```
git clone https://github.com/paljs/nextjs-admin-template.git

cd nextjs-admin-template

yarn install

yarn dev
```

![screenshot](./src/images/screenshot1.png)

![screenshot](./src/images/screenshot2.png)

![screenshot](./src/images/screenshot3.png)

![screenshot](./src/images/screenshot4.png)
