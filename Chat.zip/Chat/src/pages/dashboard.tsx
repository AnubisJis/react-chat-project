import React from 'react';
import Layout from 'Layouts';

const Home = () => {
  return <Layout title="Home" />;
};
export default Home;
